<template>
  <div id="nav">
    <router-link to="/books">Books</router-link>
    <router-link to="/authors">Authors</router-link>
  </div>
  <router-view/>
</template>

<script>

export default {
    name: 'App',
    components: {
      
    }
}
</script>

<style>
#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  max-width: 960px;
  margin: 0 auto;
}
#nav {
  padding: 30px;
}
#nav a {
  font-weight: bold;
  color: #2c3e50;
  text-decoration: none;
  padding: 10px;
  border-radius: 4px;
}
#nav a.router-link-exact-active {
  color: white;
  background: #157347;
}
</style>
